# Picture Slider
### Technologies Used
#### HTML5, CSS3, jQuery 3.2
 - Run  :  `git clone https://github.com/getwebem/picSlider.git`
 - Run  :  `cd picSlider`
 - Run :  `Brackets .`
 - Open :  `Index.html`
 - Browser:  `Live Preview`  
 - [View Demo](http://getwebem.com/picSlider/)  
<br/><br/>
<br/><br/>
<br/><br/>
![pic1](https://raw.githubusercontent.com/getwebem/README/master/picSlider/Screen%20Shot%202017-08-07%20at%2021.52.16.png)
<br/><br/>
